- Start app  with spring 
  mvn spring-boot:run -Dport=8088
  
- Start app with jetty
  mvn jetty:run -Djetty.http.port=8088