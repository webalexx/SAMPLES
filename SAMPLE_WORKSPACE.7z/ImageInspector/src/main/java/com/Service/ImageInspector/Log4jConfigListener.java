package com.Service.ImageInspector;

import java.io.FileNotFoundException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.web.Log4jServletContextListener;
import org.apache.logging.log4j.web.Log4jWebSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.util.ServletContextPropertyUtils;
import org.springframework.web.util.WebUtils;

/**
 * <code>Log4jConfigListener</code> erlaubt für die Konfiguration der log4jConfigLocation die Verwendung eines Platzhalters, dessen Name
 * über den Context-Parameter {@link #WEBAPP_CONFIG_VARIABLE_NAME_PARAM} gesetzt werden kann. Wenn es keinen Wert für den Platzhalter gibt
 * wird ein Defaultwert {@link #DEFAULT_FALLBACK_LOCATION} das SystemProperty {@link #WEBAPP_CONFIG_VARIABLE_NAME_PARAM} gesetzt.
 * <p>
 * Die eigentliche Log4j-Konfiguration wird dann durch die Klasse {@link Log4jServletContextListener} vorgenommen.
 * </p>
 *
 * @author akarpachev
 */
public final class Log4jConfigListener extends Log4jServletContextListener {

    /** Name des Initparameters für den Variablennamen. */
    public static final String WEBAPP_CONFIG_VARIABLE_NAME_PARAM = "webappConfigVariableName";

    /** Default-Fallback-Location. */
    private static final String DEFAULT_FALLBACK_LOCATION = "/WEB-INF";

    /** Logger. */
    private static final Logger LOGGER = LoggerFactory.getLogger(Log4jConfigListener.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public void contextInitialized(ServletContextEvent event) {

        final ServletContext servletContext = event.getServletContext();

        final String varName = servletContext.getInitParameter(WEBAPP_CONFIG_VARIABLE_NAME_PARAM);

        String location = servletContext.getInitParameter(Log4jWebSupport.LOG4J_CONFIG_LOCATION);

        // wenn die ConfigLocation noch einen Platzhalter für die angegebene Variable enthält,
        // aber kein Variablenwert gesetzt ist, wird der Wert auf einen Fallbackwert gesetzt.
        if ((varName != null) && (location != null) && containsConfigVariable(location, varName) && !isConfigVariableSet(varName)) {
            servletContext.log("Setting system property " + varName + " to fallback value " + DEFAULT_FALLBACK_LOCATION);
            System.setProperty(varName, DEFAULT_FALLBACK_LOCATION);
        }

        // Expose the web app root system property.
        WebUtils.setWebAppRootSystemProperty(servletContext);

        // Resolve property placeholders before potentially resolving a real path.
        location = ServletContextPropertyUtils.resolvePlaceholders(location, servletContext);

        if (!ResourceUtils.isUrl(location)) {
            // Consider a plain file path as relative to the web application root directory.
            try {
                location = WebUtils.getRealPath(servletContext, location);
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                LOGGER.error("Kannt nicht der Path defenieren {}", e);

            }
        }

        String path = System.getProperty("rewe.root");

        LoggerContext loggetContext = Configurator.initialize(null, location);

        if (loggetContext == null) {
            LOGGER.error("LoggerContext ist nicht für edrewe-webapp initialisiert und ist NULL. ");
        } else {
            System.out.println("rewe.root =" + System.getProperty("rewe.root"));
            LOGGER.info("LoggerContext für edrewe-webapp ist initialisiert.");

        }

        super.contextInitialized(event);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void contextDestroyed(ServletContextEvent event) {

        LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
        Configurator.shutdown(ctx);
        super.contextDestroyed(event);

    }

    /**
     * Liefert die Angabe, ob die angegebene Location den Platzhalter für die angegebene Variable enthält.
     *
     * @param location die Location
     * @param varName der Variablenname
     * @return Liefert die Angabe, ob die angegebene Location den Platzhalter für die angegebene Variable enthält
     */
    private static boolean containsConfigVariable(String location, String varName) {
        final String searchTerm = "${" + varName + "}";
        return location.contains(searchTerm);
    }

    /**
     * Liefert die Angabe, ob die angegebene Variable einen Wert als Systemproperty oder Umgebungsvariable hat.
     *
     * @param varName der Variablenname
     * @return Liefert die Angabe, ob die angegebene Variable einen Wert als Systemproperty oder Umgebungsvariable hat
     */
    private static boolean isConfigVariableSet(String varName) {
        String propVal = System.getProperty(varName);
        if (propVal == null) {
            // Fall back to searching the system environment.
            propVal = System.getenv(varName);
        }
        return (propVal != null);
    }
}
